#ifndef LED_H
#define LED_H

void initLED();
void testLED(int led);
void turnOnLed(int led);
void turnOffLed(unsigned int led);

#endif