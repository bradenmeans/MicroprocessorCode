#ifndef SWITCH_H
#define SWITCH_H

void initSwitch();

#endif 